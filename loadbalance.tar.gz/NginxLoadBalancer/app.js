const express = require('express')
const router = express.Router();
const PORT = process.argv[3] || 3000;
const app = express()

console.log(process.argv)

app.get('176.88.60.251', (req,res ,next) => {
    res.send('Ben Çalışıyorum' + PORT)
})

app.use('176.88.60.251',router)

app.listen(PORT, () => {
    console.log('Çalışıyor' + " " + PORT)
})